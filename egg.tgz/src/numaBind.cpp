// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Bind to NUMA node"); }
int main(){
  announce();
  return lionss_run_workload("numaBind");
}
