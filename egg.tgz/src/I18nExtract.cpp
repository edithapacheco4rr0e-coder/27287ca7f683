// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Extract i18n messages"); }
int main(){
  announce();
  return lionss_run_workload("I18nExtract");
}
