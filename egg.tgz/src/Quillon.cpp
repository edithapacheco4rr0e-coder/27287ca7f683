// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Temper quillon guard\n", stdout);
  return lionss_run_workload("Quillon");
}
