// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Encode hybrid lossless\n", stdout);
  return lionss_run_workload("wavpackHybrid");
}
