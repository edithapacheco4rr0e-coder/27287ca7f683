// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Apply 3D LUT\n", stdout);
  return lionss_run_workload("lut-grade");
}
